<?php

$dbHost = "localhost";
$dbUsername = "root";
$dbUserPassword = "";
$dbName = "slimfitshop";

$table = 'product_review';

$id       = $_GET['id'];

$con =  new PDO( "mysql:host=".$dbHost.";"."dbname=".$dbName, $dbUsername, $dbUserPassword); 
$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "DELETE FROM ".$table." WHERE userID = ?";        
$q = $con->prepare($sql);

$response = $q->execute(array($id));      

 header('Location: comments.php');

?>


