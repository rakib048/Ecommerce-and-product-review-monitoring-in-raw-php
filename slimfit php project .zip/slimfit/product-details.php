<?php require('func/config.php'); ?>
<?php

	$id = trim($_GET['id']);
	$product_query = "select * from shop_items where Id = $id";
	$product = $user->fetch_products($product_query);
 ?>
<?php include('includes/front/header.php');?>

	<section>
		<div class="container">
			<div class="row">

				<?php include('includes/front/sidebar.php');?>
				<div class="col-sm-9 padding-right">
					<?php foreach ($product as $item) :?>
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img alt="product 1" src="assets/uploads/<?php echo $item['Image'];?>">
							</div>
						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<!-- <img src="assets/front/images/product-details/new" class="newarrival" alt="" /> -->
								<h2><?php echo $item['Name'];?></h2>
								<p>Web ID: <?php echo $item['Id'];?></p>
								<!-- <img src="assets/front/images/product-details/rating.png" alt="" /> -->
								<span>
									<span>BDT <?php echo $item['Price'];?></span>

									<a ref="<?php echo $item['Id'];?>" class="btn btn-default add-cart-button" href="cart.php"><i class="fa fa-shopping-cart"></i>Add to cart</a>
								</span>
								<p><b>Availability:</b> In Stock</p>
								<p><b>Condition:</b> New</p>
								<p><b>Brand:</b> <?php echo $user->getCategory($item['Brand']);?></p>
								<p><b>Description:</b><br> <?php echo $item['Description'];?></p>
								<!-- <a href=""><img src="assets/front/images/product-details/share.png" class="share img-responsive"  alt="" /></a> -->
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
				<?php endforeach; ?>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php

$connect = new PDO("mysql:host=localhost;dbname=slimfitshop", "root", "");

if(isset($_POST['submit'])) {

	
    date_default_timezone_set('Asia/Dhaka');
	$userid       = $_GET['id'];
	$username     = $_POST['username'];
	$usermail     = $_POST['usermail'];
	$review       = $_POST['review'];
	$current_date =  date('Y-m-d H:i:s');

	$query = "INSERT INTO product_review 
  (userID,name,email,review,redate) 
  VALUES (:userID,:name,:email,:review,:redate)
  ";
  $statement = $connect->prepare($query);
  $statement->execute(
   array(
    ':userID'   => $userid,
    ':name'     => $username, 
    ':email'    => $usermail,
    ':review'   => $review,
    ':redate'     => $current_date
   
   )
  );

 $result = $statement->fetchAll();

 if(isset($result))
 {
  ?>
	<div class="alert alert-success">
	  <strong>Success!</strong> Thanks for your comment.
	</div>
  <?php
 }

}


?>


  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Product Review</a></li>
    <li><a data-toggle="tab" href="#menu1">Add Review</a></li>
    
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      
	<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "slimfitshop";
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

$sql = "SELECT 	userID,name,redate,review FROM product_review";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
    	if($row['userID'] == $_GET['id']) {
	        ?>
			<div class="reviews">
			  <div class="row blockquote review-item">
			    <div class="col-md-3 text-center">
			      <img class="rounded-circle reviewer" src="http://standaloneinstaller.com/upload/avatar.png">
			      <div class="caption">
			        <small>by <a href="#joe"><?=ucfirst($row['name'])?></a></small>
			      </div>
			    </div>
			    <div class="col-md-9">
			    	<br>
			      <p class="review-text"><?=$row['review']?></p>
			      <small class="review-date"><?=$row['redate']?></small>
			    </div>                          
			  </div>  
			</div>
    	<?php
		}

	   echo "<br>";
    } 

} else {
    ?>
	<div class="alert alert-danger">
  		<strong>Danger!</strong> No Review Found In this Product.
	</div>
    <?php
}

mysqli_close($conn);
?>

    </div>
    <br>
    <div id="menu1" class="tab-pane fade">
    <form method="post" action="">
		<div class="form-group">
		  <label for="usr">Name:</label>
		 <input type="text" name="username" placeholder="Enter Your Name" class="form-control" id="usr">
		</div>
		<div class="form-group">
			<label for="email">Email address:</label>
			<input type="email" placeholder="Enter your mail" name="usermail" class="form-control" id="useremail">
		</div>
	    <div class="form-group">
	      <label for="comment">Review:</label>
	      <textarea class="form-control" rows="3" placeholder="write here..." name="review" id="comment"></textarea>
	    </div>
	     <button type="submit"  name="submit" class="btn btn-default">Submit</button>
	  </form>
    </div>
    
  </div>

				<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">Featured items</h2>

						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<?php
									$similar_products_query = "select * from shop_items where FeaturedItem = 1 LIMIT 3";
									$similar_products = $user->fetch_products($similar_products_query);
								 ?>
								<div class="item active">
									<?php include('includes/front/similar-items.php');?>
									</div>
							</div>
						</div>
					</div><!--/recommended_items-->

				</div>
			</div>
		</div>
	</section>

<?php include('includes/front/footer.php');?>
