<footer id="footer"><!--Footer-->

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p class="pull-left">Copyright &copy; <?php echo date('Y'); ?> Slimfit Collections BD. All rights reserved.</p>
            </div>
        </div>
    </div>

</footer><!--/Footer-->

<script src="assets/front/js/jquery.js"></script>
<script src="assets/front/js/price-range.js"></script>
<script src="assets/front/js/jquery.scrollUp.min.js"></script>
<script src="assets/front/js/bootstrap.min.js"></script>
<script src="assets/front/js/jquery.prettyPhoto.js"></script>
<script src="assets/front/js/main.js"></script>
<script src="assets/front/js/functions.js"></script>
<script src="assets/front/js/bootbox.js"></script>


</body>
</html>
