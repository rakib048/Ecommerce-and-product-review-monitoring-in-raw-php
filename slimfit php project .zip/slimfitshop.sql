-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2018 at 09:59 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slimfitshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `Id` int(11) NOT NULL,
  `Name` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`Id`, `Name`) VALUES
(1, 'Nike'),
(2, 'Dolce and Gabbana'),
(3, 'GUcci'),
(5, 'Nike'),
(6, 'Dolce and Gabbana'),
(7, 'GUcci'),
(9, 'mamen'),
(10, 'My isht'),
(11, 'Nike'),
(12, 'Nike Sports'),
(13, 'My isht'),
(14, 'Pantiesu'),
(15, 'ii'),
(16, 'sd');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `Id` int(11) NOT NULL,
  `Name` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`Id`, `Name`) VALUES
(1, 'Slimfit Suits'),
(2, 'Slimfit shirts'),
(3, 'Slimfit Trousers'),
(4, 'Slimfit Dress'),
(5, 'Ladies Tops'),
(6, 'Shoes'),
(7, 'Ankara Clothes');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `Id` int(11) NOT NULL,
  `CartId` text NOT NULL,
  `ItemId` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Image` text NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `DatePlaced` date NOT NULL,
  `CustomerId` int(11) NOT NULL,
  `Destination` text NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`Id`, `CartId`, `ItemId`, `Name`, `Image`, `Price`, `Quantity`, `Total`, `DatePlaced`, `CustomerId`, `Destination`, `Status`) VALUES
(1, '2017070517191', 19, 'Cuffling Shirt', 'assets/uploads/769518.jpg', 450, 4, 1800, '2017-07-05', 1, '1', 3),
(2, '2017070517201', 20, 'Polo Neck T-Shirt', 'assets/uploads/156575.jpg', 250, 2, 500, '2017-07-05', 1, '2', 3),
(3, '2017070517221', 19, 'Cuffling Shirt', 'assets/uploads/769518.jpg', 450, 1, 450, '2017-07-05', 1, '2', 3),
(4, '2017070517281', 20, 'Polo Neck T-Shirt', 'assets/uploads/156575.jpg', 250, 1, 250, '2017-07-05', 1, '3', 3),
(5, '2017070517311', 20, 'Polo Neck T-Shirt', 'assets/uploads/156575.jpg', 250, 1, 250, '2017-07-05', 1, '2', 3),
(6, '2017070517311', 19, 'Cuffling Shirt', 'assets/uploads/769518.jpg', 450, 1, 450, '2017-07-05', 1, '2', 3);

-- --------------------------------------------------------

--
-- Table structure for table `deliverycarts`
--

CREATE TABLE `deliverycarts` (
  `Id` int(11) NOT NULL,
  `CartId` text NOT NULL,
  `DeliveryCost` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliverycarts`
--

INSERT INTO `deliverycarts` (`Id`, `CartId`, `DeliveryCost`) VALUES
(1, '2017070517191', 400),
(2, '2017070517201', 200),
(3, '2017070517221', 200),
(4, '2017070517281', 150),
(5, '2017070517311', 200),
(6, '2017070517311', 200);

-- --------------------------------------------------------

--
-- Table structure for table `deliverypoints`
--

CREATE TABLE `deliverypoints` (
  `Id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliverypoints`
--

INSERT INTO `deliverypoints` (`Id`, `Name`, `Amount`) VALUES
(2, '', 200),
(3, '', 150);

-- --------------------------------------------------------

--
-- Table structure for table `product_review`
--

CREATE TABLE `product_review` (
  `id` int(50) NOT NULL,
  `userID` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `review` varchar(1000) NOT NULL,
  `redate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profilemaster`
--

CREATE TABLE `profilemaster` (
  `Id` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `PhoneNumber` varchar(200) NOT NULL,
  `IdNumber` int(11) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Role` varchar(200) NOT NULL,
  `Status` varchar(200) NOT NULL,
  `tokenCode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profilemaster`
--

INSERT INTO `profilemaster` (`Id`, `Name`, `Email`, `PhoneNumber`, `IdNumber`, `Password`, `Role`, `Status`, `tokenCode`) VALUES
(1, 'Abucheri Derrick', 'derrickwitness@gmail.com', '(254) 070-196463', 0, '$2y$10$rsSX6LnhI1tojLPEvyyVI.9hWErWxUXwkqyfrL/DMNTSJQyT2mtve', '1', 'Y', 'cc99fcd05b753beda3d123d255ac59d4'),
(25, 'Sarah Cheminingwa', 'cheminingwa@gmail.com', '(254) 711-755788', 0, '$2y$10$rsSX6LnhI1tojLPEvyyVI.9hWErWxUXwkqyfrL/DMNTSJQyT2mtve', '2', 'Y', 'c29f1997098ad28d20c5021375175660'),
(26, 'William Odianga', 'william@gmail.com', '(254) 711-755788', 0, '$2y$10$rsSX6LnhI1tojLPEvyyVI.9hWErWxUXwkqyfrL/DMNTSJQyT2mtve', '3', 'Y', 'f5b156fa63b20bc1f689dd5db109f370'),
(29, 'Attache Profile', 'Attache@gmail.com', '(254) 711-755788', 0, '$2y$10$rsSX6LnhI1tojLPEvyyVI.9hWErWxUXwkqyfrL/DMNTSJQyT2mtve', '5', 'Y', 'f5b156fa63b20bc1f689dd5db109f370'),
(30, 'Mejba Ahmed', 'mejba.13@gmail.com', '0172374124', 56, '$2y$10$9zmwVb2.QUejLoGTQqK3X.DKAY/PnrKfxvlmx/b0aLEWLBqjIRmZ2', '2', 'Y', '0ad5588eb5d59ba84887b9827ce5a308'),
(31, 'rakib', 'rakibhossain048@gmail.com', ' 711-755788', 45, '$2y$10$GHaR6tkrwtWrfI9r3t/kDO2oq.3JM.kxTZdVu8h/B.JBHkoutkChC', '2', 'Y', '93132195981b2f29b7ef6efca0210c98'),
(32, 'rakib', 'rakib@admin.com', '01723565677', 56, '$2y$10$KhSapJE.Ero0fJ2gF.U3ReuQjSNgBbUkVFYE2W6fHVikgRt.71/6K', '2', 'Y', 'e25e16bbc260593a89b7a388bafa8638');

-- --------------------------------------------------------

--
-- Table structure for table `shop_items`
--

CREATE TABLE `shop_items` (
  `Id` int(11) NOT NULL,
  `Category` int(11) NOT NULL,
  `Brand` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Image` text NOT NULL,
  `Colour` text NOT NULL,
  `Description` text NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `SetAsNew` int(11) NOT NULL,
  `FeaturedItem` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_items`
--

INSERT INTO `shop_items` (`Id`, `Category`, `Brand`, `Name`, `Image`, `Colour`, `Description`, `Price`, `Quantity`, `SetAsNew`, `FeaturedItem`) VALUES
(20, 2, 1, 'Polo Neck T-Shirt', '737197.jpg', 'Blue', 'Cotton Wear', 250, 10, 2, 2),
(19, 1, 2, 'Cuffling Shirt', '188950.jpg', 'White', 'This is a cuffing shirt', 450, 15, 1, 1),
(23, 5, 11, 'Ladies tops nike', '898889.jpg', 'black', 'ladies top and best quality', 50, 1, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `deliverycarts`
--
ALTER TABLE `deliverycarts`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `deliverypoints`
--
ALTER TABLE `deliverypoints`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product_review`
--
ALTER TABLE `product_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profilemaster`
--
ALTER TABLE `profilemaster`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `shop_items`
--
ALTER TABLE `shop_items`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `deliverycarts`
--
ALTER TABLE `deliverycarts`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `deliverypoints`
--
ALTER TABLE `deliverypoints`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product_review`
--
ALTER TABLE `product_review`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profilemaster`
--
ALTER TABLE `profilemaster`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `shop_items`
--
ALTER TABLE `shop_items`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
